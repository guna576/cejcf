(self["webpackChunkmlops_assist"] = self["webpackChunkmlops_assist"] || []).push([["lib_index_js"],{

/***/ "./lib/components/FeatureModal.js":
/*!****************************************!*\
  !*** ./lib/components/FeatureModal.js ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FeatureModal": () => (/* binding */ FeatureModal)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @mui/material/Button */ "./node_modules/@mui/material/Button/Button.js");
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @mui/material/styles */ "./node_modules/@mui/material/styles/styled.js");
/* harmony import */ var _mui_material_Dialog__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @mui/material/Dialog */ "./node_modules/@mui/material/Dialog/Dialog.js");
/* harmony import */ var _mui_material_DialogTitle__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @mui/material/DialogTitle */ "./node_modules/@mui/material/DialogTitle/DialogTitle.js");
/* harmony import */ var _mui_material_DialogContent__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @mui/material/DialogContent */ "./node_modules/@mui/material/DialogContent/DialogContent.js");
/* harmony import */ var _mui_material_DialogActions__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @mui/material/DialogActions */ "./node_modules/@mui/material/DialogActions/DialogActions.js");
/* harmony import */ var _mui_material_IconButton__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @mui/material/IconButton */ "./node_modules/@mui/material/IconButton/IconButton.js");
/* harmony import */ var _mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @mui/icons-material/Close */ "./node_modules/@mui/icons-material/Close.js");
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @mui/material/Typography */ "./node_modules/@mui/material/Typography/Typography.js");
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @mui/material */ "webpack/sharing/consume/default/@mui/material/@mui/material");
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material_CircularProgress__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @mui/material/CircularProgress */ "./node_modules/@mui/material/CircularProgress/CircularProgress.js");
/* harmony import */ var _utils_ExportEnvVars__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../utils/ExportEnvVars */ "./lib/utils/ExportEnvVars.js");
/* harmony import */ var _utils_PostData__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../utils/PostData */ "./lib/utils/PostData.js");
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! sweetalert2 */ "webpack/sharing/consume/default/sweetalert2/sweetalert2");
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(sweetalert2__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_lab__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @mui/lab */ "webpack/sharing/consume/default/@mui/lab/@mui/lab");
/* harmony import */ var _mui_lab__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_lab__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _utils_FetchFeatureList__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../utils/FetchFeatureList */ "./lib/utils/FetchFeatureList.js");
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @jupyterlab/notebook */ "webpack/sharing/consume/default/@jupyterlab/notebook");
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_5__);
var __rest = (undefined && undefined.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};



















// convert the given string pascal scale
function toPascalCase(str) {
    return (' ' + str)
        .toLowerCase()
        .replace(/[^a-zA-Z0-9]+(.)/g, (match, chr) => chr.toUpperCase());
}
const BootstrapDialog = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_6__["default"])(_mui_material_Dialog__WEBPACK_IMPORTED_MODULE_7__["default"])(({ theme }) => ({
    '& .MuiDialogContent-root': {
        padding: theme.spacing(2)
    },
    '& .MuiDialogActions-root': {
        padding: theme.spacing(1)
    }
}));
const BootstrapDialogTitle = (props) => {
    const { children, onClose } = props, other = __rest(props, ["children", "onClose"]);
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_DialogTitle__WEBPACK_IMPORTED_MODULE_8__["default"], Object.assign({ sx: { m: 0, p: 2 } }, other),
        children,
        onClose ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_IconButton__WEBPACK_IMPORTED_MODULE_9__["default"], { "aria-label": "close", onClick: onClose, sx: {
                position: 'absolute',
                right: 8,
                top: 8,
                color: theme => theme.palette.grey[500]
            } },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_10__["default"], null))) : null));
};
// Modal Component for Feature Code push workflow - Start
function ModalComponent({ code, panel }) {
    const [open, setOpen] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const [openInput, setOpenInput] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [openTest, setOpenTest] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [backdropOpen, setBackdropOpen] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [className, setClassName] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [testObj, setTestObj] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [pascal, setPascal] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const handleClose = () => setOpen(false);
    const handleOpenInput = () => setOpenInput(true);
    // const handleOpenTest = () => setOpenTest(true);
    const handleCloseTest = () => setOpenTest(false);
    const handleCloseInput = () => setOpenInput(false);
    const handleOpenBackdrop = () => setBackdropOpen(true);
    const handleCloseBackdrop = () => setBackdropOpen(false);
    // Push Code API call
    const pushCode = (featureCode, fileName) => {
        handleCloseInput();
        handleOpenBackdrop();
        const data = new FormData();
        data.append(fileName, featureCode);
        const commit_message = `Pushed ${fileName}`;
        data.append('message', commit_message);
        data.append('branch', _utils_ExportEnvVars__WEBPACK_IMPORTED_MODULE_11__.branch);
        const headers = new Headers();
        headers.append('Authorization', `Bearer ${_utils_ExportEnvVars__WEBPACK_IMPORTED_MODULE_11__.access_token}`);
        const url = `${_utils_ExportEnvVars__WEBPACK_IMPORTED_MODULE_11__.BASE_URL}/${_utils_ExportEnvVars__WEBPACK_IMPORTED_MODULE_11__.VERSION}/repositories/${_utils_ExportEnvVars__WEBPACK_IMPORTED_MODULE_11__.workspace}/${_utils_ExportEnvVars__WEBPACK_IMPORTED_MODULE_11__.repo_slug}/src`;
        (0,_utils_PostData__WEBPACK_IMPORTED_MODULE_12__.postData)({ url, headers, data })
            .then(response => {
            handleCloseBackdrop();
            if (response.status === 201) {
                sweetalert2__WEBPACK_IMPORTED_MODULE_3___default().fire({
                    title: 'Success!',
                    text: 'Feature Code Pushed Successfully!',
                    icon: 'success'
                });
            }
            else {
                sweetalert2__WEBPACK_IMPORTED_MODULE_3___default().fire({
                    title: 'Error!',
                    text: 'Failed to Push Feature Code',
                    icon: 'error'
                });
            }
        })
            .catch(err => {
            console.log(err);
            handleCloseBackdrop();
            sweetalert2__WEBPACK_IMPORTED_MODULE_3___default().fire({
                title: 'Error!',
                text: 'Failed to Push Feature Code',
                icon: 'error'
            });
        });
    };
    // handle submit from feature input modal
    const handleSubmit = () => {
        const featureCode = code.replace('FeatureClass', pascal);
        const fileName = `${pascal.toLowerCase()}.py`;
        setLoading(true);
        (0,_utils_FetchFeatureList__WEBPACK_IMPORTED_MODULE_13__.fetchFeatureList)().then((featureList) => {
            setLoading(false);
            if (featureList.includes(fileName)) {
                sweetalert2__WEBPACK_IMPORTED_MODULE_3___default().fire({
                    title: 'Feature name already exists!',
                    text: 'A feature with this name already exits. A new version of this feature will be pushed.',
                    icon: 'info',
                    showCancelButton: true
                }).then(result => {
                    if (result.isConfirmed) {
                        pushCode(featureCode, fileName);
                    }
                });
            }
            else {
                pushCode(featureCode, fileName);
            }
        });
    };
    const handleTest = () => {
        panel.content.activeCellIndex = panel.content.widgets.length - 1;
        _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_5__.NotebookActions.insertBelow(panel.content);
        _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_5__.NotebookActions.replaceSelection(panel.content, code);
        _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_5__.NotebookActions.run(panel.content, panel.context.sessionContext);
        const obj = `obj = FeatureClass()\nobj.processFeature(${testObj})`;
        _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_5__.NotebookActions.insertBelow(panel.content);
        _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_5__.NotebookActions.replaceSelection(panel.content, obj);
        _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_5__.NotebookActions.run(panel.content, panel.context.sessionContext);
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(BootstrapDialog, { onClose: handleClose, "aria-labelledby": "customized-dialog-title", open: open },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(BootstrapDialogTitle, { id: "customized-dialog-title", onClose: handleClose }, "Feature Code"),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_DialogContent__WEBPACK_IMPORTED_MODULE_14__["default"], { dividers: true },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_Typography__WEBPACK_IMPORTED_MODULE_15__["default"], { gutterBottom: true },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("pre", null,
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("code", null, code)))),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_DialogActions__WEBPACK_IMPORTED_MODULE_16__["default"], null,
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_Button__WEBPACK_IMPORTED_MODULE_17__["default"], { autoFocus: true, onClick: () => {
                        handleClose();
                        handleOpenInput();
                    } }, "Continue"))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(BootstrapDialog, { onClose: handleCloseTest, "aria-labelledby": "customized-dialog-title", open: openTest },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(BootstrapDialogTitle, { id: "customized-dialog-title", onClose: handleCloseTest }, "Feature Input"),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_DialogContent__WEBPACK_IMPORTED_MODULE_14__["default"], { dividers: true, style: { padding: '24px' } },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "modal-content" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_Typography__WEBPACK_IMPORTED_MODULE_15__["default"], { gutterBottom: true },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_2__.TextField, { fullWidth: true, label: "Feature Input", variant: "outlined", size: "small", value: testObj, onChange: e => {
                                setTestObj(e.target.value);
                            }, autoFocus: true })))),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_DialogActions__WEBPACK_IMPORTED_MODULE_16__["default"], null,
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_Button__WEBPACK_IMPORTED_MODULE_17__["default"], { autoFocus: true, onClick: handleCloseTest }, "Cancel"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_Button__WEBPACK_IMPORTED_MODULE_17__["default"], { autoFocus: true, onClick: () => {
                        handleCloseTest();
                        handleTest();
                    } }, "Test Code"))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(BootstrapDialog, { onClose: handleCloseInput, "aria-labelledby": "customized-dialog-title", open: openInput },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(BootstrapDialogTitle, { id: "customized-dialog-title", onClose: handleCloseInput }, "Required Inputs"),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_DialogContent__WEBPACK_IMPORTED_MODULE_14__["default"], { dividers: true, style: { padding: '24px' } },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "modal-content" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_Typography__WEBPACK_IMPORTED_MODULE_15__["default"], { gutterBottom: true },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_2__.TextField, { fullWidth: true, label: "Feature Class", variant: "outlined", size: "small", value: className, onChange: e => {
                                setClassName(e.target.value);
                                setPascal(toPascalCase(e.target.value));
                            }, autoFocus: true })),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "res" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "res-tag" }, "Resultant Classname"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "res-content" }, pascal)))),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_DialogActions__WEBPACK_IMPORTED_MODULE_16__["default"], null,
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_Button__WEBPACK_IMPORTED_MODULE_17__["default"], { autoFocus: true, onClick: handleCloseInput }, "Cancel"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_lab__WEBPACK_IMPORTED_MODULE_4__.LoadingButton, { onClick: handleSubmit, loading: loading, variant: "outlined" }, "Push Code"))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Backdrop, { open: backdropOpen, sx: { zIndex: 1000 } },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_CircularProgress__WEBPACK_IMPORTED_MODULE_18__["default"], { color: "inherit" }))));
}
// Modal Component End
// Modal Widget as ReactWidget Start
class FeatureModal extends _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.ReactWidget {
    constructor(code, panel) {
        super();
        this.addClass('jp-ReactWidget');
        this.code = code;
        this.panel = panel;
    }
    // Render Modal Component (Validation Modal + Feature Input Modal)
    render() {
        return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(ModalComponent, { code: this.code, panel: this.panel });
    }
}
// Modal Widget End


/***/ }),

/***/ "./lib/components/FetchModal.js":
/*!**************************************!*\
  !*** ./lib/components/FetchModal.js ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FetchModal": () => (/* binding */ FetchModal)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @mui/material/Button */ "./node_modules/@mui/material/Button/Button.js");
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @mui/material/styles */ "./node_modules/@mui/material/styles/styled.js");
/* harmony import */ var _mui_material_Dialog__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @mui/material/Dialog */ "./node_modules/@mui/material/Dialog/Dialog.js");
/* harmony import */ var _mui_material_DialogTitle__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @mui/material/DialogTitle */ "./node_modules/@mui/material/DialogTitle/DialogTitle.js");
/* harmony import */ var _mui_material_DialogContent__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @mui/material/DialogContent */ "./node_modules/@mui/material/DialogContent/DialogContent.js");
/* harmony import */ var _mui_material_IconButton__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @mui/material/IconButton */ "./node_modules/@mui/material/IconButton/IconButton.js");
/* harmony import */ var _mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @mui/icons-material/Close */ "./node_modules/@mui/icons-material/Close.js");
/* harmony import */ var _utils_FetchFeature__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../utils/FetchFeature */ "./lib/utils/FetchFeature.js");
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @mui/material */ "webpack/sharing/consume/default/@mui/material/@mui/material");
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
var __rest = (undefined && undefined.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};











const BootstrapDialog = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_3__["default"])(_mui_material_Dialog__WEBPACK_IMPORTED_MODULE_4__["default"])(({ theme }) => ({
    '& .MuiDialogContent-root': {
        padding: theme.spacing(2)
    },
    '& .MuiDialogActions-root': {
        padding: theme.spacing(1)
    }
}));
const BootstrapDialogTitle = (props) => {
    const { children, onClose } = props, other = __rest(props, ["children", "onClose"]);
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_DialogTitle__WEBPACK_IMPORTED_MODULE_5__["default"], Object.assign({ sx: { m: 0, p: 2 } }, other),
        children,
        onClose ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_IconButton__WEBPACK_IMPORTED_MODULE_6__["default"], { "aria-label": "close", onClick: onClose, sx: {
                position: 'absolute',
                right: 8,
                top: 8,
                color: theme => theme.palette.grey[500]
            } },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_7__["default"], null))) : null));
};
function ModalComponent(props) {
    const [open, setOpen] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const [searchQ, setSearchQ] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [searchList, setSearchList] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const handleClose = () => setOpen(false);
    const handleFetch = (featureName) => {
        handleClose();
        (0,_utils_FetchFeature__WEBPACK_IMPORTED_MODULE_8__.fetchFeature)({
            featureName: featureName,
            panel: props.panel
        });
    };
    const handleSearch = (q) => {
        setSearchList([]);
        q = q.toLowerCase();
        props.featureList.map((featureName) => {
            if (featureName.includes(q)) {
                setSearchList(searchList => [...searchList, featureName]);
            }
        });
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(BootstrapDialog, { onClose: handleClose, "aria-labelledby": "customized-dialog-title", open: open },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(BootstrapDialogTitle, { id: "customized-dialog-title", onClose: handleClose }, "Feature List"),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_DialogContent__WEBPACK_IMPORTED_MODULE_9__["default"], { dividers: true },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "search-q" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_2__.TextField, { fullWidth: true, label: "Search Query", variant: "outlined", size: "small", value: searchQ, onChange: e => {
                            setSearchQ(e.target.value ? e.target.value.toLowerCase() : '');
                            handleSearch(e.target.value);
                        }, autoFocus: true })),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("ul", { className: "feature-list" }, searchQ !== '' ? (searchList !== [] ? (searchList.map((featureName) => {
                    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("li", { className: "feature-item" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "feature-name" }, featureName),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_Button__WEBPACK_IMPORTED_MODULE_10__["default"], { variant: "contained", color: "primary", onClick: () => handleFetch(featureName), size: "small" }, "Fetch")));
                })) : (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("li", { className: "feature-item" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "feature-name" }, "No Results Found")))) : (props.featureList &&
                    props.featureList.map((featureName) => {
                        return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("li", { className: "feature-item" },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "feature-name" }, featureName),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_Button__WEBPACK_IMPORTED_MODULE_10__["default"], { variant: "contained", color: "primary", onClick: () => handleFetch(featureName), size: "small" }, "Fetch")));
                    })))))));
}
// Modal Widget as ReactWidget Start
class FetchModal extends _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.ReactWidget {
    constructor(featureList, panel) {
        super();
        this.addClass('jp-ReactWidget');
        this.featureList = featureList;
        this.panel = panel;
    }
    // Render Modal Component (Validation Modal + Feature Input Modal)
    render() {
        return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(ModalComponent, { featureList: this.featureList, panel: this.panel });
    }
}
// Modal Widget End


/***/ }),

/***/ "./lib/components/Progress.js":
/*!************************************!*\
  !*** ./lib/components/Progress.js ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Progress": () => (/* binding */ Progress)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @mui/material */ "webpack/sharing/consume/default/@mui/material/@mui/material");
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);



function ModalComponent() {
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Backdrop, { open: true, sx: { zIndex: 1000 } },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_2__.CircularProgress, { color: "inherit" })));
}
// Progress Widget as ReactWidget Start
class Progress extends _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.ReactWidget {
    // Render Modal Component (Validation Modal + Feature Input Modal)
    render() {
        return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(ModalComponent, null);
    }
}
// Progress Widget End


/***/ }),

/***/ "./lib/index.js":
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _widgets_Feature__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./widgets/Feature */ "./lib/widgets/Feature.js");
// import { Login } from './components/Login';

/**
 * Initialization data for the mlops-assist extension.
 */
function activateExtension(app) {
    console.log('JupyterLab Extension Activated');
    app.docRegistry.addWidgetExtension('Notebook', new _widgets_Feature__WEBPACK_IMPORTED_MODULE_0__.Feature(app));
    // const widget = new Login();
    // widget.id = 'login-widget';
    // widget.title.iconClass = 'fas fa-sign-in-alt';
    // widget.title.caption = 'Login';
    // app.shell.add(widget, 'left', { rank: 1 });
}
0.;
const plugin = {
    id: 'mlops-assist:plugin',
    autoStart: true,
    activate: activateExtension
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (plugin);


/***/ }),

/***/ "./lib/utils/ExportEnvVars.js":
/*!************************************!*\
  !*** ./lib/utils/ExportEnvVars.js ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "workspace": () => (/* binding */ workspace),
/* harmony export */   "repo_slug": () => (/* binding */ repo_slug),
/* harmony export */   "access_token": () => (/* binding */ access_token),
/* harmony export */   "BASE_URL": () => (/* binding */ BASE_URL),
/* harmony export */   "VERSION": () => (/* binding */ VERSION),
/* harmony export */   "refresh_token": () => (/* binding */ refresh_token),
/* harmony export */   "branch": () => (/* binding */ branch)
/* harmony export */ });
const workspace = 'noob_ankit';
const repo_slug = 'test';
const access_token = 'EIClpbWtdfd7S0PhUWNJEFXKR_IRvA0l21KZVRIo5CLo_1fzitykJNe6K9TsLNKOtglRoGsZdnRv-vu1d-XjRyvF6xiwHkXcClgUXq9R3X_qsFVnh3pPsmKT'; // localStorage.getItem('access_token');
const BASE_URL = 'https://api.bitbucket.org';
const VERSION = '2.0';
const refresh_token = '4hfYH5Vus5Huk7QAQ8';
const branch = 'feature';


/***/ }),

/***/ "./lib/utils/FetchFeature.js":
/*!***********************************!*\
  !*** ./lib/utils/FetchFeature.js ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "fetchFeature": () => (/* binding */ fetchFeature)
/* harmony export */ });
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/notebook */ "webpack/sharing/consume/default/@jupyterlab/notebook");
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! sweetalert2 */ "webpack/sharing/consume/default/sweetalert2/sweetalert2");
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(sweetalert2__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _utils_ExportEnvVars__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../utils/ExportEnvVars */ "./lib/utils/ExportEnvVars.js");
// import { Cell, ICellModel } from '@jupyterlab/cells';



function fetchFeature({ featureName, panel }) {
    // Fetch FeatureCode from Repo Using the Commit ID
    const url = `${_utils_ExportEnvVars__WEBPACK_IMPORTED_MODULE_2__.BASE_URL}/${_utils_ExportEnvVars__WEBPACK_IMPORTED_MODULE_2__.VERSION}/repositories/${_utils_ExportEnvVars__WEBPACK_IMPORTED_MODULE_2__.workspace}/${_utils_ExportEnvVars__WEBPACK_IMPORTED_MODULE_2__.repo_slug}/src/${_utils_ExportEnvVars__WEBPACK_IMPORTED_MODULE_2__.branch}/${featureName}`;
    const headers = {
        Authorization: `Bearer ${_utils_ExportEnvVars__WEBPACK_IMPORTED_MODULE_2__.access_token}`
    };
    fetch(url, {
        method: 'GET',
        headers: headers
    })
        .then(response => response.text())
        .then(data => {
        sweetalert2__WEBPACK_IMPORTED_MODULE_1___default().fire({
            title: 'Success!',
            text: 'Feature Code Fetched Successfully!',
            icon: 'success'
        });
        // Display Code in a New Notebook Cell
        panel.content.activeCellIndex = panel.content.widgets.length - 1;
        _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__.NotebookActions.insertBelow(panel.content);
        _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__.NotebookActions.replaceSelection(panel.content, data);
        // NotebookActions.run(panel.content, panel.context.sessionContext);
        // const cell: Cell =
        //   panel.content.widgets[panel.content.widgets.length - 1];
        // const model: ICellModel = cell.model;
        // const newList: string[] = [];
        // newList.push('existingFeature');
        // model.metadata.set('tags', newList);
        // let className = '';
        // for (let i = 6; i < data.length; i++) {
        //   if (data[i] === ':') {
        //     break;
        //   }
        //   className += data[i];
        // }
        // const obj = 'obj = ' + className + '()';
        // NotebookActions.insertBelow(panel.content);
        // NotebookActions.replaceSelection(panel.content, obj);
        // NotebookActions.run(panel.content, panel.context.sessionContext);
    })
        .catch(err => {
        console.log(err);
    });
}


/***/ }),

/***/ "./lib/utils/FetchFeatureList.js":
/*!***************************************!*\
  !*** ./lib/utils/FetchFeatureList.js ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "fetchFeatureList": () => (/* binding */ fetchFeatureList)
/* harmony export */ });
/* harmony import */ var _ExportEnvVars__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ExportEnvVars */ "./lib/utils/ExportEnvVars.js");

async function fetchFeatureList() {
    const url = `${_ExportEnvVars__WEBPACK_IMPORTED_MODULE_0__.BASE_URL}/${_ExportEnvVars__WEBPACK_IMPORTED_MODULE_0__.VERSION}/repositories/${_ExportEnvVars__WEBPACK_IMPORTED_MODULE_0__.workspace}/${_ExportEnvVars__WEBPACK_IMPORTED_MODULE_0__.repo_slug}/src/${_ExportEnvVars__WEBPACK_IMPORTED_MODULE_0__.branch}/`;
    const featureList = [];
    await fetch(url, {
        method: 'GET',
        headers: {
            Authorization: `Bearer ${_ExportEnvVars__WEBPACK_IMPORTED_MODULE_0__.access_token}`
        }
    })
        .then(response => response.json())
        .then(data => {
        data.values.map((value) => {
            if (value.path.search('.py') !== -1) {
                featureList.push(value.path);
            }
        });
    })
        .catch(err => console.log(err));
    return featureList;
}


/***/ }),

/***/ "./lib/utils/PostData.js":
/*!*******************************!*\
  !*** ./lib/utils/PostData.js ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "postData": () => (/* binding */ postData)
/* harmony export */ });
async function postData(props) {
    const response = await fetch(props.url, {
        method: 'POST',
        headers: props.headers,
        body: props.data
    });
    return response;
}


/***/ }),

/***/ "./lib/utils/ProcessFeature.js":
/*!*************************************!*\
  !*** ./lib/utils/ProcessFeature.js ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "processFeature": () => (/* binding */ processFeature)
/* harmony export */ });
function processFeature(panel) {
    let processedFeature = '';
    let processedFeatureImport = '';
    let processedFeatureModel = '';
    let returnFeatureObject = '';
    let returnModelObject = '';
    let featureInput = '';
    let featureCode = '';
    const codeList = [];
    const importList = [];
    const modelList = [];
    for (let i = 0; i < panel.content.widgets.length; i++) {
        const cell = panel.content.widgets[i];
        const model = cell.model;
        if (model.type === 'code') {
            let tagList = model.metadata.get('tags');
            if (tagList === undefined) {
                tagList = [];
            }
            else {
                if (containsTag('featureCode', tagList)) {
                    codeList.push(model.value.text);
                }
                if (containsTag('importCode', tagList)) {
                    importList.push(model.value.text);
                }
                if (containsTag('modelCode', tagList)) {
                    modelList.push(model.value.text);
                }
                if (containsTag('returnFeatureObject', tagList)) {
                    returnFeatureObject = model.value.text;
                }
                if (containsTag('returnModelObject', tagList)) {
                    returnModelObject = model.value.text;
                }
                if (containsTag('featureInput', tagList)) {
                    featureInput = model.value.text;
                }
            }
        }
    }
    if (returnFeatureObject) {
        codeList.push(`return ${returnFeatureObject}`);
    }
    if (returnModelObject) {
        modelList.push(`return ${returnModelObject}`);
    }
    processedFeatureImport = importList.join('\n');
    featureCode = processedFeatureImport + '\n\n';
    processedFeature = codeList.join('\n');
    processedFeature = processedFeature.replace(/^\s+|\s+$/g, '');
    processedFeature = processedFeature.replace(/^/gm, ' '.repeat(4));
    const medSig1 = `def preprocess(${featureInput}):\n`;
    processedFeature = medSig1 + processedFeature;
    featureCode += processedFeature + '\n\n';
    processedFeatureModel = modelList.join('\n');
    processedFeatureModel = processedFeatureModel.replace(/^\s+|\s+$/g, '');
    processedFeatureModel = processedFeatureModel.replace(/^/gm, ' '.repeat(4));
    const medSig2 = `def model(${featureInput}):\n`;
    processedFeatureModel = medSig2 + processedFeatureModel;
    featureCode += processedFeatureModel;
    return featureCode;
}
function containsTag(tag, tagList) {
    for (let j = 0; j < tagList.length; j++) {
        if (tagList[j] === tag) {
            return true;
        }
    }
    return false;
}


/***/ }),

/***/ "./lib/widgets/Feature.js":
/*!********************************!*\
  !*** ./lib/widgets/Feature.js ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Feature": () => (/* binding */ Feature)
/* harmony export */ });
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _lumino_disposable__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @lumino/disposable */ "webpack/sharing/consume/default/@lumino/disposable");
/* harmony import */ var _lumino_disposable__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_lumino_disposable__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _utils_FetchFeatureList__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../utils/FetchFeatureList */ "./lib/utils/FetchFeatureList.js");
/* harmony import */ var _utils_ProcessFeature__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../utils/ProcessFeature */ "./lib/utils/ProcessFeature.js");
/* harmony import */ var _components_FeatureModal__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../components/FeatureModal */ "./lib/components/FeatureModal.js");
/* harmony import */ var _components_FetchModal__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../components/FetchModal */ "./lib/components/FetchModal.js");
/* harmony import */ var _components_Progress__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../components/Progress */ "./lib/components/Progress.js");








// import { TagModal } from '../components/TagModal';
// import { Cell, ICellModel } from '@jupyterlab/cells';
// import { PushModal } from '../components/PushModal';
// function containsTag(tag: string, tagList: string[]) {
//   for (let j = 0; j < tagList.length; j++) {
//     if (tagList[j] === tag) {
//       return true;
//     }
//   }
//   return false;
// }
class Feature {
    constructor(app) {
        this.app = app;
    }
    createNew(panel, context) {
        const featureHandler = () => {
            // Grabbing code from code cells and Make Feature Class
            const featureCode = (0,_utils_ProcessFeature__WEBPACK_IMPORTED_MODULE_3__.processFeature)(panel);
            // add modal widget to app header
            const widget = new _components_FeatureModal__WEBPACK_IMPORTED_MODULE_4__.FeatureModal(featureCode, panel);
            widget.title.label = 'React Widget';
            widget.title.icon = _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.reactIcon;
            widget.id = 'modal-widget';
            this.app.shell.add(widget, 'header');
        };
        const fetchHandler = () => {
            const progressWidget = new _components_Progress__WEBPACK_IMPORTED_MODULE_5__.Progress();
            progressWidget.title.label = 'React Widget';
            progressWidget.title.icon = _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.reactIcon;
            progressWidget.id = 'modal-widget';
            this.app.shell.add(progressWidget, 'header');
            // Fetch all features from latest commit
            (0,_utils_FetchFeatureList__WEBPACK_IMPORTED_MODULE_6__.fetchFeatureList)()
                .then((featureList) => {
                progressWidget.close();
                console.log(featureList);
                // Add fetch feature Modal to header
                const widget = new _components_FetchModal__WEBPACK_IMPORTED_MODULE_7__.FetchModal(featureList, panel);
                widget.title.label = 'React Widget';
                widget.title.icon = _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.reactIcon;
                widget.id = 'modal-widget';
                this.app.shell.add(widget, 'header');
            })
                .catch(err => {
                progressWidget.close();
                console.log(err);
            });
        };
        // const pushHandler = () => {
        //   let featureCode = '';
        //   for (let i = 0; i < panel.content.widgets.length; i++) {
        //     const cell: Cell = panel.content.widgets[i];
        //     const model: ICellModel = cell.model;
        //     if (model.type === 'code') {
        //       let tagList = model.metadata.get('tags') as string[];
        //       if (tagList === undefined) {
        //         tagList = [];
        //       } else {
        //         if (containsTag('existingFeature', tagList)) {
        //           featureCode = model.value.text;
        //         }
        //       }
        //     }
        //   }
        //   const inter = featureCode.split('\n')[0];
        //   const fileName =
        //     inter.substring(6, inter.length - 1).toLowerCase() + '.py';
        //   const widget = new PushModal(featureCode, fileName);
        //   widget.title.label = 'React Widget';
        //   widget.title.icon = reactIcon;
        //   widget.id = 'modal-widget';
        //   this.app.shell.add(widget, 'header');
        // };
        // const tagHandler = () => {
        //   const tagWidget = new TagModal(panel);
        //   tagWidget.title.label = 'React Widget';
        //   tagWidget.title.icon = reactIcon;
        //   tagWidget.id = 'modal-widget';
        //   this.app.shell.add(tagWidget, 'header');
        // };
        // Creating Toolbar Button
        const FeatureBtn = new _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.ToolbarButton({
            className: 'feature-btn',
            label: 'Push',
            onClick: featureHandler,
            tooltip: 'Extract Feature'
        });
        // Creating Toolbar Button
        const FetchBtn = new _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.ToolbarButton({
            className: 'feature-btn',
            label: 'Fetch',
            onClick: fetchHandler,
            tooltip: 'Fetch Feature'
        });
        // const PushBtn = new ToolbarButton({
        //   className: 'feature-btn',
        //   label: 'Push',
        //   onClick: pushHandler,
        //   tooltip: 'Push Feature'
        // });
        // const TagCellBtn = new ToolbarButton({
        //   className: 'tagcell-btn',
        //   label: 'Tag Cells',
        //   onClick: tagHandler,
        //   tooltip: 'Tag Cells in the specified range'
        // });
        // Adding FeatureBtn Button to Notebook Panel
        panel.toolbar.insertItem(11, 'Extract Feature', FeatureBtn);
        panel.toolbar.insertItem(12, 'Fetch Feature', FetchBtn);
        //panel.toolbar.insertItem(13, 'Push Feature', PushBtn);
        // panel.toolbar.insertItem(3, 'Tag Cells', TagCellBtn);
        return new _lumino_disposable__WEBPACK_IMPORTED_MODULE_2__.DisposableDelegate(() => {
            FeatureBtn.dispose();
            FetchBtn.dispose();
        });
    }
}


/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js":
/*!**********************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/interopRequireDefault.js ***!
  \**********************************************************************/
/***/ ((module) => {

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    "default": obj
  };
}

module.exports = _interopRequireDefault, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ "./node_modules/@mui/icons-material/Close.js":
/*!***************************************************!*\
  !*** ./node_modules/@mui/icons-material/Close.js ***!
  \***************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js");

Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = void 0;

var _createSvgIcon = _interopRequireDefault(__webpack_require__(/*! ./utils/createSvgIcon */ "./node_modules/@mui/icons-material/utils/createSvgIcon.js"));

var _jsxRuntime = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");

var _default = (0, _createSvgIcon.default)( /*#__PURE__*/(0, _jsxRuntime.jsx)("path", {
  d: "M19 6.41 17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"
}), 'Close');

exports["default"] = _default;

/***/ }),

/***/ "./node_modules/@mui/icons-material/utils/createSvgIcon.js":
/*!*****************************************************************!*\
  !*** ./node_modules/@mui/icons-material/utils/createSvgIcon.js ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";


Object.defineProperty(exports, "__esModule", ({
  value: true
}));
Object.defineProperty(exports, "default", ({
  enumerable: true,
  get: function () {
    return _utils.createSvgIcon;
  }
}));

var _utils = __webpack_require__(/*! @mui/material/utils */ "./node_modules/@mui/material/utils/index.js");

/***/ }),

/***/ "./node_modules/@mui/material/DialogTitle/DialogTitle.js":
/*!***************************************************************!*\
  !*** ./node_modules/@mui/material/DialogTitle/DialogTitle.js ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/esm/extends */ "./node_modules/@babel/runtime/helpers/esm/extends.js");
/* harmony import */ var _babel_runtime_helpers_esm_objectWithoutPropertiesLoose__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/esm/objectWithoutPropertiesLoose */ "./node_modules/@babel/runtime/helpers/esm/objectWithoutPropertiesLoose.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! prop-types */ "./node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! clsx */ "./node_modules/clsx/dist/clsx.m.js");
/* harmony import */ var _mui_base__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @mui/base */ "./node_modules/@mui/base/composeClasses/composeClasses.js");
/* harmony import */ var _Typography__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../Typography */ "./node_modules/@mui/material/Typography/Typography.js");
/* harmony import */ var _styles_styled__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../styles/styled */ "./node_modules/@mui/material/styles/styled.js");
/* harmony import */ var _styles_useThemeProps__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../styles/useThemeProps */ "./node_modules/@mui/material/styles/useThemeProps.js");
/* harmony import */ var _dialogTitleClasses__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./dialogTitleClasses */ "./node_modules/@mui/material/DialogTitle/dialogTitleClasses.js");
/* harmony import */ var _Dialog_DialogContext__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../Dialog/DialogContext */ "./node_modules/@mui/material/Dialog/DialogContext.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");


const _excluded = ["className", "id"];











const useUtilityClasses = ownerState => {
  const {
    classes
  } = ownerState;
  const slots = {
    root: ['root']
  };
  return (0,_mui_base__WEBPACK_IMPORTED_MODULE_5__["default"])(slots, _dialogTitleClasses__WEBPACK_IMPORTED_MODULE_6__.getDialogTitleUtilityClass, classes);
};

const DialogTitleRoot = (0,_styles_styled__WEBPACK_IMPORTED_MODULE_7__["default"])(_Typography__WEBPACK_IMPORTED_MODULE_8__["default"], {
  name: 'MuiDialogTitle',
  slot: 'Root',
  overridesResolver: (props, styles) => styles.root
})({
  padding: '16px 24px',
  flex: '0 0 auto'
});
const DialogTitle = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2__.forwardRef(function DialogTitle(inProps, ref) {
  const props = (0,_styles_useThemeProps__WEBPACK_IMPORTED_MODULE_9__["default"])({
    props: inProps,
    name: 'MuiDialogTitle'
  });

  const {
    className,
    id: idProp
  } = props,
        other = (0,_babel_runtime_helpers_esm_objectWithoutPropertiesLoose__WEBPACK_IMPORTED_MODULE_1__["default"])(props, _excluded);

  const ownerState = props;
  const classes = useUtilityClasses(ownerState);
  const {
    titleId: id = idProp
  } = react__WEBPACK_IMPORTED_MODULE_2__.useContext(_Dialog_DialogContext__WEBPACK_IMPORTED_MODULE_10__["default"]);
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx)(DialogTitleRoot, (0,_babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__["default"])({
    component: "h2",
    className: (0,clsx__WEBPACK_IMPORTED_MODULE_3__["default"])(classes.root, className),
    ownerState: ownerState,
    ref: ref,
    variant: "h6",
    id: id
  }, other));
});
 true ? DialogTitle.propTypes
/* remove-proptypes */
= {
  // ----------------------------- Warning --------------------------------
  // | These PropTypes are generated from the TypeScript type definitions |
  // |     To update them edit the d.ts file and run "yarn proptypes"     |
  // ----------------------------------------------------------------------

  /**
   * The content of the component.
   */
  children: (prop_types__WEBPACK_IMPORTED_MODULE_11___default().node),

  /**
   * Override or extend the styles applied to the component.
   */
  classes: (prop_types__WEBPACK_IMPORTED_MODULE_11___default().object),

  /**
   * @ignore
   */
  className: (prop_types__WEBPACK_IMPORTED_MODULE_11___default().string),

  /**
   * @ignore
   */
  id: (prop_types__WEBPACK_IMPORTED_MODULE_11___default().string),

  /**
   * The system prop that allows defining system overrides as well as additional CSS styles.
   */
  sx: prop_types__WEBPACK_IMPORTED_MODULE_11___default().oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_11___default().arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_11___default().oneOfType([(prop_types__WEBPACK_IMPORTED_MODULE_11___default().func), (prop_types__WEBPACK_IMPORTED_MODULE_11___default().object), (prop_types__WEBPACK_IMPORTED_MODULE_11___default().bool)])), (prop_types__WEBPACK_IMPORTED_MODULE_11___default().func), (prop_types__WEBPACK_IMPORTED_MODULE_11___default().object)])
} : 0;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (DialogTitle);

/***/ }),

/***/ "./node_modules/@mui/material/utils/createChainedFunction.js":
/*!*******************************************************************!*\
  !*** ./node_modules/@mui/material/utils/createChainedFunction.js ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _mui_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @mui/utils */ "./node_modules/@mui/utils/esm/createChainedFunction.js");

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_mui_utils__WEBPACK_IMPORTED_MODULE_0__["default"]);

/***/ }),

/***/ "./node_modules/@mui/material/utils/deprecatedPropType.js":
/*!****************************************************************!*\
  !*** ./node_modules/@mui/material/utils/deprecatedPropType.js ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _mui_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @mui/utils */ "./node_modules/@mui/utils/esm/deprecatedPropType.js");

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_mui_utils__WEBPACK_IMPORTED_MODULE_0__["default"]);

/***/ }),

/***/ "./node_modules/@mui/material/utils/index.js":
/*!***************************************************!*\
  !*** ./node_modules/@mui/material/utils/index.js ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "capitalize": () => (/* reexport safe */ _capitalize__WEBPACK_IMPORTED_MODULE_0__["default"]),
/* harmony export */   "createChainedFunction": () => (/* reexport safe */ _createChainedFunction__WEBPACK_IMPORTED_MODULE_1__["default"]),
/* harmony export */   "createSvgIcon": () => (/* reexport safe */ _createSvgIcon__WEBPACK_IMPORTED_MODULE_2__["default"]),
/* harmony export */   "debounce": () => (/* reexport safe */ _debounce__WEBPACK_IMPORTED_MODULE_3__["default"]),
/* harmony export */   "deprecatedPropType": () => (/* reexport safe */ _deprecatedPropType__WEBPACK_IMPORTED_MODULE_4__["default"]),
/* harmony export */   "isMuiElement": () => (/* reexport safe */ _isMuiElement__WEBPACK_IMPORTED_MODULE_5__["default"]),
/* harmony export */   "ownerDocument": () => (/* reexport safe */ _ownerDocument__WEBPACK_IMPORTED_MODULE_6__["default"]),
/* harmony export */   "ownerWindow": () => (/* reexport safe */ _ownerWindow__WEBPACK_IMPORTED_MODULE_7__["default"]),
/* harmony export */   "requirePropFactory": () => (/* reexport safe */ _requirePropFactory__WEBPACK_IMPORTED_MODULE_8__["default"]),
/* harmony export */   "setRef": () => (/* reexport safe */ _setRef__WEBPACK_IMPORTED_MODULE_9__["default"]),
/* harmony export */   "unstable_useEnhancedEffect": () => (/* reexport safe */ _useEnhancedEffect__WEBPACK_IMPORTED_MODULE_10__["default"]),
/* harmony export */   "unstable_useId": () => (/* reexport safe */ _useId__WEBPACK_IMPORTED_MODULE_11__["default"]),
/* harmony export */   "unsupportedProp": () => (/* reexport safe */ _unsupportedProp__WEBPACK_IMPORTED_MODULE_12__["default"]),
/* harmony export */   "useControlled": () => (/* reexport safe */ _useControlled__WEBPACK_IMPORTED_MODULE_13__["default"]),
/* harmony export */   "useEventCallback": () => (/* reexport safe */ _useEventCallback__WEBPACK_IMPORTED_MODULE_14__["default"]),
/* harmony export */   "useForkRef": () => (/* reexport safe */ _useForkRef__WEBPACK_IMPORTED_MODULE_15__["default"]),
/* harmony export */   "useIsFocusVisible": () => (/* reexport safe */ _useIsFocusVisible__WEBPACK_IMPORTED_MODULE_16__["default"]),
/* harmony export */   "unstable_ClassNameGenerator": () => (/* reexport safe */ _mui_base__WEBPACK_IMPORTED_MODULE_17__["default"])
/* harmony export */ });
/* harmony import */ var _capitalize__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./capitalize */ "./node_modules/@mui/material/utils/capitalize.js");
/* harmony import */ var _createChainedFunction__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./createChainedFunction */ "./node_modules/@mui/material/utils/createChainedFunction.js");
/* harmony import */ var _createSvgIcon__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./createSvgIcon */ "./node_modules/@mui/material/utils/createSvgIcon.js");
/* harmony import */ var _debounce__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./debounce */ "./node_modules/@mui/material/utils/debounce.js");
/* harmony import */ var _deprecatedPropType__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./deprecatedPropType */ "./node_modules/@mui/material/utils/deprecatedPropType.js");
/* harmony import */ var _isMuiElement__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./isMuiElement */ "./node_modules/@mui/material/utils/isMuiElement.js");
/* harmony import */ var _ownerDocument__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./ownerDocument */ "./node_modules/@mui/material/utils/ownerDocument.js");
/* harmony import */ var _ownerWindow__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./ownerWindow */ "./node_modules/@mui/material/utils/ownerWindow.js");
/* harmony import */ var _requirePropFactory__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./requirePropFactory */ "./node_modules/@mui/material/utils/requirePropFactory.js");
/* harmony import */ var _setRef__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./setRef */ "./node_modules/@mui/material/utils/setRef.js");
/* harmony import */ var _useEnhancedEffect__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./useEnhancedEffect */ "./node_modules/@mui/material/utils/useEnhancedEffect.js");
/* harmony import */ var _useId__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./useId */ "./node_modules/@mui/material/utils/useId.js");
/* harmony import */ var _unsupportedProp__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./unsupportedProp */ "./node_modules/@mui/material/utils/unsupportedProp.js");
/* harmony import */ var _useControlled__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./useControlled */ "./node_modules/@mui/material/utils/useControlled.js");
/* harmony import */ var _useEventCallback__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./useEventCallback */ "./node_modules/@mui/material/utils/useEventCallback.js");
/* harmony import */ var _useForkRef__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./useForkRef */ "./node_modules/@mui/material/utils/useForkRef.js");
/* harmony import */ var _useIsFocusVisible__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./useIsFocusVisible */ "./node_modules/@mui/material/utils/useIsFocusVisible.js");
/* harmony import */ var _mui_base__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @mui/base */ "./node_modules/@mui/base/generateUtilityClass/ClassNameGenerator.js");



















/***/ }),

/***/ "./node_modules/@mui/material/utils/setRef.js":
/*!****************************************************!*\
  !*** ./node_modules/@mui/material/utils/setRef.js ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _mui_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @mui/utils */ "./node_modules/@mui/utils/esm/setRef.js");

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_mui_utils__WEBPACK_IMPORTED_MODULE_0__["default"]);

/***/ }),

/***/ "./node_modules/@mui/utils/esm/deprecatedPropType.js":
/*!***********************************************************!*\
  !*** ./node_modules/@mui/utils/esm/deprecatedPropType.js ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ deprecatedPropType)
/* harmony export */ });
function deprecatedPropType(validator, reason) {
  if (false) {}

  return (props, propName, componentName, location, propFullName) => {
    const componentNameSafe = componentName || '<<anonymous>>';
    const propFullNameSafe = propFullName || propName;

    if (typeof props[propName] !== 'undefined') {
      return new Error(`The ${location} \`${propFullNameSafe}\` of ` + `\`${componentNameSafe}\` is deprecated. ${reason}`);
    }

    return null;
  };
}

/***/ })

}]);
//# sourceMappingURL=lib_index_js.5a5e076c23753245fea7.js.map
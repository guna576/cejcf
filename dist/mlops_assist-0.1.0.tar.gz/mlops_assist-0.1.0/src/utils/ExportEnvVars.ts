export const workspace = 'noob_ankit';
export const repo_slug = 'test';
export const access_token = 'EIClpbWtdfd7S0PhUWNJEFXKR_IRvA0l21KZVRIo5CLo_1fzitykJNe6K9TsLNKOtglRoGsZdnRv-vu1d-XjRyvF6xiwHkXcClgUXq9R3X_qsFVnh3pPsmKT'// localStorage.getItem('access_token');
export const BASE_URL = 'https://api.bitbucket.org';
export const VERSION = '2.0';
export const refresh_token = '4hfYH5Vus5Huk7QAQ8';
export const branch = 'feature';
